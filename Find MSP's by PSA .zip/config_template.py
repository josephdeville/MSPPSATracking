# PSA User Discovery - Configuration File
# Copy this to config.py and add your API keys

# ============================================================================
# API KEYS
# ============================================================================

# Firecrawl (Required for web scraping)
# Get your key: https://firecrawl.dev
FIRECRAWL_API_KEY = ""  # Example: "fc-abc123..."

# BuiltWith (Optional - for tech stack validation)
# Get your key: https://builtwith.com/api
BUILTWITH_API_KEY = ""  # Example: "bw-xyz789..."

# Hunter.io (Optional - for email finding)
# Get your key: https://hunter.io/api
HUNTER_API_KEY = ""  # Example: "hunter_abc..."

# Apollo.io (Optional - for contact enrichment)
# Get your key: https://app.apollo.io/#/settings/integrations/api
APOLLO_API_KEY = ""  # Example: "apollo_xyz..."

# HubSpot (Optional - for CRM export)
# Get your key: https://app.hubspot.com/portal-recommend/api-keys
HUBSPOT_API_KEY = ""  # Example: "pat-na1-..."

# ============================================================================
# TARGET PSA PLATFORMS
# ============================================================================

TARGET_PLATFORMS = [
    'connectwise',    # ConnectWise PSA/Manage
    'autotask',       # Autotask PSA (Datto)
    'halo',           # HaloPSA
    'kaseya',         # Kaseya BMS
    'syncro',         # Syncro MSP Platform
]

# ============================================================================
# SCRAPING CONFIGURATION
# ============================================================================

# Rate limiting (seconds between requests)
SCRAPE_DELAY = 3

# Maximum pages to scrape per platform
MAX_PAGES_PER_PLATFORM = 5

# Use stealth proxy (costs more credits but better success rate)
USE_STEALTH_PROXY = False

# ============================================================================
# FILTERING CRITERIA
# ============================================================================

# Minimum company size (employees)
MIN_COMPANY_SIZE = 10

# Maximum company size (employees)  
MAX_COMPANY_SIZE = 500

# Target industries (leave empty for all)
TARGET_INDUSTRIES = [
    "IT Services",
    "Managed Service Provider",
    "Technology",
    "Computer & Network Security",
    "Information Technology"
]

# Minimum review rating (1-5)
MIN_RATING = 3.0

# ============================================================================
# ENRICHMENT SETTINGS
# ============================================================================

# Enable email finding
FIND_EMAILS = True

# Enable email verification
VERIFY_EMAILS = True

# Enable LinkedIn profile lookup
FIND_LINKEDIN = True

# Enable tech stack detection
DETECT_TECH_STACK = False  # Set to True if you have BuiltWith API key

# ============================================================================
# JOB TITLES TO TARGET
# ============================================================================

TARGET_JOB_TITLES = [
    "IT Director",
    "CTO",
    "Chief Technology Officer",
    "VP of Technology",
    "VP Technology",
    "Director of IT",
    "Director of Operations",
    "Operations Director",
    "Service Desk Manager",
    "IT Manager",
    "Technical Operations Manager",
    "MSP Owner",
    "Managing Director"
]

# ============================================================================
# EXPORT SETTINGS
# ============================================================================

# Export format (csv, json, both)
EXPORT_FORMAT = "both"

# Output directory
OUTPUT_DIR = "/mnt/user-data/outputs"

# Export to HubSpot automatically
AUTO_EXPORT_TO_HUBSPOT = False

# HubSpot pipeline to use
HUBSPOT_PIPELINE = "default"

# ============================================================================
# LEAD SCORING WEIGHTS
# ============================================================================

SCORING_WEIGHTS = {
    'psa_confirmed_builtwith': 40,      # Tech stack confirms PSA usage
    'psa_mentioned_in_review': 20,      # Found in G2/Capterra review
    'psa_in_job_posting': 20,           # PSA mentioned in job listings
    'company_size_match': 15,           # Company in target size range
    'industry_match': 15,               # Company in target industry
    'email_verified': 10,               # Email address verified
}

# Minimum score to export (0-100)
MIN_EXPORT_SCORE = 40

# ============================================================================
# ADVANCED SETTINGS
# ============================================================================

# Request timeout (seconds)
REQUEST_TIMEOUT = 60

# Retry failed requests
RETRY_FAILED = True

# Maximum retries
MAX_RETRIES = 3

# Log level (DEBUG, INFO, WARNING, ERROR)
LOG_LEVEL = "INFO"

# Save raw scraped data
SAVE_RAW_DATA = True

# ============================================================================
# CLAY INTEGRATION
# ============================================================================

# Clay API settings (if pushing data directly to Clay)
CLAY_API_KEY = ""
CLAY_WORKSPACE_ID = ""
CLAY_TABLE_ID = ""

# ============================================================================
# NOTIFICATION SETTINGS
# ============================================================================

# Send completion notifications
ENABLE_NOTIFICATIONS = False

# Slack webhook for notifications
SLACK_WEBHOOK_URL = ""

# Email for notifications
NOTIFICATION_EMAIL = ""

# ============================================================================
# PROXY SETTINGS (If not using Firecrawl's proxies)
# ============================================================================

# Use custom proxy
USE_CUSTOM_PROXY = False

# Proxy URL
PROXY_URL = ""

# ============================================================================
# NOTES
# ============================================================================

# Recommended starting configuration:
# 1. Add FIRECRAWL_API_KEY (required)
# 2. Set TARGET_PLATFORMS to 1-2 platforms for testing
# 3. Keep SCRAPE_DELAY at 3+ seconds
# 4. Start with MAX_PAGES_PER_PLATFORM = 2
# 5. Run test, then scale up

# Cost estimates:
# - Firecrawl: 1 credit per page, 5 if using stealth
# - 5 platforms × 2 pages each = 10 credits (free tier gives 500/month)
# - Expected: 20-50 companies per platform per page
# - Total: 200-500 companies for free tier usage

# Next steps after configuration:
# 1. python3 psa_user_discovery.py --config config.py
# 2. Review output CSV
# 3. Import to Clay for enrichment
# 4. Export high-scoring leads to HubSpot
