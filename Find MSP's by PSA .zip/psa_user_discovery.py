#!/usr/bin/env python3
"""
PSA User Discovery Tool
Scrapes G2/Capterra reviews to find companies using PSA platforms
Author: Joe Deville - Clay Works of Art
"""

import requests
import json
import time
from datetime import datetime
from typing import List, Dict, Optional
import re


class PSAUserDiscovery:
    """Find users of PSA platforms like ConnectWise, Autotask, Kaseya, Halo"""
    
    def __init__(self, firecrawl_api_key: Optional[str] = None):
        self.firecrawl_api_key = firecrawl_api_key
        self.base_url = "https://api.firecrawl.dev/v1"
        
        # PSA platforms to track
        self.psa_platforms = {
            'connectwise': {
                'name': 'ConnectWise PSA',
                'g2_url': 'https://www.g2.com/products/connectwise-psa/reviews',
                'capterra_url': 'https://www.capterra.com/p/130007/ConnectWise-PSA/',
            },
            'autotask': {
                'name': 'Autotask PSA',
                'g2_url': 'https://www.g2.com/products/autotask-psa/reviews',
                'capterra_url': 'https://www.capterra.com/p/132515/Autotask/',
            },
            'kaseya': {
                'name': 'Kaseya BMS',
                'g2_url': 'https://www.g2.com/products/kaseya-bms/reviews',
                'capterra_url': 'https://www.capterra.com/p/132517/Kaseya-BMS/',
            },
            'halo': {
                'name': 'HaloPSA',
                'g2_url': 'https://www.g2.com/products/halopsa/reviews',
                'capterra_url': 'https://www.capterra.com/p/207330/HaloPSA/',
            },
            'syncro': {
                'name': 'Syncro',
                'g2_url': 'https://www.g2.com/products/syncro/reviews',
                'capterra_url': 'https://www.capterra.com/p/177090/Syncro/',
            },
        }
    
    def scrape_with_firecrawl(self, url: str, platform_name: str) -> Dict:
        """
        Scrape review page using Firecrawl API
        """
        if not self.firecrawl_api_key:
            print("⚠️  No Firecrawl API key provided - returning mock data")
            return self._get_mock_data(platform_name)
        
        headers = {
            'Authorization': f'Bearer {self.firecrawl_api_key}',
            'Content-Type': 'application/json'
        }
        
        # Extraction schema for review data
        extraction_schema = {
            'type': 'object',
            'properties': {
                'reviews': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'reviewer_name': {
                                'type': 'string',
                                'description': 'Full name of the reviewer'
                            },
                            'reviewer_title': {
                                'type': 'string',
                                'description': 'Job title of the reviewer'
                            },
                            'company_name': {
                                'type': 'string',
                                'description': 'Company or organization name'
                            },
                            'company_size': {
                                'type': 'string',
                                'description': 'Employee count range (e.g., 11-50, 51-200)'
                            },
                            'industry': {
                                'type': 'string',
                                'description': 'Industry or vertical'
                            },
                            'rating': {
                                'type': 'number',
                                'description': 'Star rating (1-5)'
                            },
                            'review_date': {
                                'type': 'string',
                                'description': 'Date of review'
                            }
                        }
                    }
                }
            }
        }
        
        payload = {
            'url': url,
            'formats': ['extract'],
            'extract': {
                'schema': extraction_schema,
                'prompt': f'''Extract all reviews for {platform_name} from this page. 
                For each review, capture:
                - Reviewer full name
                - Their job title/role
                - Company name (often shown as "Company XYZ" or organization)
                - Company size in employees
                - Industry/vertical
                - Star rating
                - Review date
                
                Return comprehensive data for all visible reviews.'''
            },
            'location': {
                'country': 'US'
            }
        }
        
        try:
            print(f"🔍 Scraping {platform_name} reviews from {url}...")
            response = requests.post(
                f"{self.base_url}/scrape",
                headers=headers,
                json=payload,
                timeout=60
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"✓ Successfully scraped {platform_name}")
                return data
            else:
                print(f"✗ Error {response.status_code}: {response.text}")
                return {'error': response.text}
                
        except Exception as e:
            print(f"✗ Exception while scraping: {str(e)}")
            return {'error': str(e)}
    
    def _get_mock_data(self, platform_name: str) -> Dict:
        """Return mock data for testing without API key"""
        return {
            'extract': {
                'reviews': [
                    {
                        'reviewer_name': 'John Smith',
                        'reviewer_title': 'IT Director',
                        'company_name': 'TechServe Solutions',
                        'company_size': '51-200',
                        'industry': 'IT Services',
                        'rating': 4.5,
                        'review_date': '2024-12-15'
                    },
                    {
                        'reviewer_name': 'Sarah Johnson',
                        'reviewer_title': 'Operations Manager',
                        'company_name': 'CloudNet MSP',
                        'company_size': '11-50',
                        'industry': 'Managed Services',
                        'rating': 5.0,
                        'review_date': '2024-11-22'
                    },
                    {
                        'reviewer_name': 'Mike Chen',
                        'reviewer_title': 'Service Desk Manager',
                        'company_name': 'Infinity IT Partners',
                        'company_size': '201-500',
                        'industry': 'Technology',
                        'rating': 4.0,
                        'review_date': '2024-10-08'
                    }
                ]
            },
            'metadata': {
                'platform': platform_name,
                'scraped_at': datetime.now().isoformat(),
                'source': 'mock_data'
            }
        }
    
    def extract_domain_from_company(self, company_name: str) -> Optional[str]:
        """
        Attempt to generate likely domain from company name
        """
        if not company_name:
            return None
        
        # Remove common suffixes
        clean_name = re.sub(r'\s+(LLC|Inc|Corp|Ltd|Limited|Corporation|Company|Co\.).*$', '', company_name, flags=re.IGNORECASE)
        
        # Remove special characters and convert to lowercase
        clean_name = re.sub(r'[^a-zA-Z0-9\s]', '', clean_name)
        clean_name = clean_name.strip().lower().replace(' ', '')
        
        return f"{clean_name}.com"
    
    def process_reviews(self, reviews_data: Dict, platform: str) -> List[Dict]:
        """
        Process and enrich review data
        """
        processed = []
        
        reviews = reviews_data.get('extract', {}).get('reviews', [])
        
        for review in reviews:
            company_name = review.get('company_name', '')
            
            # Skip if no company name
            if not company_name or company_name.lower() in ['n/a', 'none', 'anonymous']:
                continue
            
            record = {
                'company_name': company_name,
                'likely_domain': self.extract_domain_from_company(company_name),
                'psa_platform': platform,
                'reviewer_name': review.get('reviewer_name'),
                'reviewer_title': review.get('reviewer_title'),
                'company_size': review.get('company_size'),
                'industry': review.get('industry'),
                'rating': review.get('rating'),
                'review_date': review.get('review_date'),
                'data_source': 'g2_reviews',
                'discovered_at': datetime.now().isoformat()
            }
            
            processed.append(record)
        
        return processed
    
    def discover_psa_users(self, platforms: Optional[List[str]] = None, delay: int = 3) -> Dict[str, List[Dict]]:
        """
        Main discovery method - scrape reviews for specified PSA platforms
        
        Args:
            platforms: List of platform keys (e.g., ['connectwise', 'autotask'])
                      If None, scrapes all platforms
            delay: Seconds to wait between requests (rate limiting)
        
        Returns:
            Dictionary mapping platform names to lists of discovered companies
        """
        if platforms is None:
            platforms = list(self.psa_platforms.keys())
        
        all_results = {}
        
        for platform_key in platforms:
            if platform_key not in self.psa_platforms:
                print(f"⚠️  Unknown platform: {platform_key}")
                continue
            
            platform_info = self.psa_platforms[platform_key]
            platform_name = platform_info['name']
            
            print(f"\n{'='*60}")
            print(f"Platform: {platform_name}")
            print(f"{'='*60}")
            
            # Scrape G2 reviews
            g2_data = self.scrape_with_firecrawl(
                platform_info['g2_url'],
                platform_name
            )
            
            # Process the review data
            companies = self.process_reviews(g2_data, platform_name)
            
            all_results[platform_name] = companies
            
            print(f"✓ Found {len(companies)} companies using {platform_name}")
            
            # Rate limiting
            if platform_key != platforms[-1]:  # Don't delay after last platform
                print(f"⏱️  Waiting {delay}s before next platform...")
                time.sleep(delay)
        
        return all_results
    
    def export_to_csv(self, results: Dict[str, List[Dict]], filename: str = None):
        """
        Export results to CSV format
        """
        import csv
        
        if filename is None:
            filename = f"psa_users_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        # Flatten all results
        all_companies = []
        for platform, companies in results.items():
            all_companies.extend(companies)
        
        if not all_companies:
            print("⚠️  No data to export")
            return None
        
        # Write CSV
        fieldnames = all_companies[0].keys()
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(all_companies)
        
        print(f"\n✓ Exported {len(all_companies)} records to {filename}")
        return filename
    
    def export_to_json(self, results: Dict[str, List[Dict]], filename: str = None):
        """
        Export results to JSON format
        """
        if filename is None:
            filename = f"psa_users_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        output = {
            'generated_at': datetime.now().isoformat(),
            'total_companies': sum(len(companies) for companies in results.values()),
            'platforms': results
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2)
        
        print(f"✓ Exported to {filename}")
        return filename
    
    def generate_summary_report(self, results: Dict[str, List[Dict]]):
        """
        Print summary statistics
        """
        print(f"\n{'='*60}")
        print("PSA USER DISCOVERY SUMMARY")
        print(f"{'='*60}\n")
        
        total_companies = sum(len(companies) for companies in results.values())
        print(f"Total Companies Discovered: {total_companies}")
        print(f"\nBreakdown by Platform:")
        
        for platform, companies in results.items():
            print(f"  • {platform}: {len(companies)} companies")
        
        # Industry breakdown
        all_companies = [c for companies in results.values() for c in companies]
        industries = {}
        for company in all_companies:
            industry = company.get('industry', 'Unknown')
            industries[industry] = industries.get(industry, 0) + 1
        
        print(f"\nTop Industries:")
        for industry, count in sorted(industries.items(), key=lambda x: x[1], reverse=True)[:5]:
            print(f"  • {industry}: {count}")
        
        # Company size breakdown
        sizes = {}
        for company in all_companies:
            size = company.get('company_size', 'Unknown')
            sizes[size] = sizes.get(size, 0) + 1
        
        print(f"\nCompany Size Distribution:")
        for size, count in sorted(sizes.items(), key=lambda x: x[1], reverse=True):
            print(f"  • {size}: {count}")
        
        print(f"\n{'='*60}\n")


def main():
    """
    Example usage
    """
    print("PSA User Discovery Tool")
    print("=" * 60)
    
    # Initialize (use environment variable for API key in production)
    api_key = None  # Set to your Firecrawl API key or leave None for mock data
    
    discovery = PSAUserDiscovery(firecrawl_api_key=api_key)
    
    # Option 1: Discover all PSA platforms
    # results = discovery.discover_psa_users()
    
    # Option 2: Target specific platforms
    target_platforms = ['connectwise', 'autotask', 'halo']
    results = discovery.discover_psa_users(platforms=target_platforms, delay=3)
    
    # Generate summary
    discovery.generate_summary_report(results)
    
    # Export results
    csv_file = discovery.export_to_csv(results)
    json_file = discovery.export_to_json(results)
    
    print(f"\n✅ Discovery complete!")
    print(f"📄 CSV: {csv_file}")
    print(f"📄 JSON: {json_file}")


if __name__ == "__main__":
    main()
