# PSA User Discovery - Clay Workflow Configuration
## Complete end-to-end automation for finding PSA users

### Workflow Overview
```
1. Scrape G2/Capterra Reviews → 2. Extract Company Data → 3. Enrich Domains
→ 4. Find Decision Makers → 5. Validate Tech Stack → 6. Export to HubSpot
```

---

## CLAY TABLE SETUP

### Table 1: PSA Review Scraper

**Column A: Platform Name**
- Manual input or import
- Values: "ConnectWise PSA", "Autotask PSA", "Kaseya BMS", "HaloPSA", "Syncro"

**Column B: G2 Review URL**
- Formula: 
```javascript
if ({{Platform Name}} === "ConnectWise PSA") {
  return "https://www.g2.com/products/connectwise-psa/reviews";
} else if ({{Platform Name}} === "Autotask PSA") {
  return "https://www.g2.com/products/autotask-psa/reviews";
} else if ({{Platform Name}} === "Kaseya BMS") {
  return "https://www.g2.com/products/kaseya-bms/reviews";
} else if ({{Platform Name}} === "HaloPSA") {
  return "https://www.g2.com/products/halopsa/reviews";
} else if ({{Platform Name}} === "Syncro") {
  return "https://www.g2.com/products/syncro/reviews";
}
```

**Column C: Scrape Reviews (HTTP API)**
- Enrichment: HTTP API
- Method: POST
- URL: `https://api.firecrawl.dev/v1/scrape`
- Headers:
```json
{
  "Authorization": "Bearer {{YOUR_FIRECRAWL_API_KEY}}",
  "Content-Type": "application/json"
}
```
- Body:
```json
{
  "url": "{{G2 Review URL}}",
  "formats": ["markdown"],
  "location": {
    "country": "US"
  }
}
```

**Column D: Parse Reviews (AI Formula)**
- Use Claude/ChatGPT enrichment
- Prompt:
```
Extract all company names, reviewer titles, and company sizes from these G2 reviews.

Reviews:
{{Scrape Reviews.markdown}}

Return as JSON array:
[
  {
    "company_name": "...",
    "reviewer_name": "...",
    "reviewer_title": "...",
    "company_size": "...",
    "industry": "...",
    "rating": ...
  }
]
```

**Column E: Expand to Rows**
- Use "Create rows from list" integration
- Input: {{Parse Reviews}}
- This creates one row per company

---

### Table 2: Company Enrichment (Auto-imported from Table 1)

**Column A: Company Name** (from Table 1)

**Column B: PSA Platform** (from Table 1)

**Column C: Find Company Domain**
- Enrichment: "Find Company" (Clearbit/Apollo)
- Input: {{Company Name}}
- Returns: domain, employee count, industry

**Column D: Validate Domain Exists**
- HTTP API: GET request to domain
- URL: `https://{{Find Company Domain.domain}}`
- Success = domain is active

**Column E: BuiltWith Tech Stack** (Optional - requires API)
- HTTP API
- URL: `https://api.builtwith.com/v20/api.json`
- Params:
```json
{
  "KEY": "{{YOUR_BUILTWITH_KEY}}",
  "LOOKUP": "{{Find Company Domain.domain}}"
}
```

**Column F: Confirm PSA Usage (AI Formula)**
- Check if BuiltWith data confirms PSA
```javascript
const technologies = {{BuiltWith Tech Stack.technologies}};
const psaPlatform = {{PSA Platform}};

if (technologies && technologies.some(tech => 
  tech.name.toLowerCase().includes(psaPlatform.toLowerCase())
)) {
  return "Confirmed";
} else {
  return "Review Mention Only";
}
```

**Column G: Find Jobs at Company**
- Enrichment: "Search for jobs"
- Company: {{Company Name}}
- Keywords: "{{PSA Platform}} OR PSA OR service desk"

**Column H: PSA in Job Postings (Formula)**
```javascript
const jobs = {{Find Jobs at Company}};
const psa = {{PSA Platform}};

if (!jobs || jobs.length === 0) return "No job data";

const hasMatch = jobs.some(job => 
  job.description?.toLowerCase().includes(psa.toLowerCase())
);

return hasMatch ? "Confirmed in Jobs" : "Not mentioned in jobs";
```

**Column I: Company LinkedIn**
- Enrichment: "Find Company on LinkedIn"
- Input: {{Company Name}}

**Column J: Employee Count**
- From LinkedIn data or Find Company
- {{Company LinkedIn.employee_count}}

**Column K: Industry**
- From LinkedIn data
- {{Company LinkedIn.industry}}

**Column L: Company HQ Location**
- {{Find Company Domain.location}}

---

### Table 3: Find Decision Makers (Auto-import from Table 2)

**Filter:** Only rows where validation score > 50%

**Column A: Company Domain** (from Table 2)

**Column B: Company Name** (from Table 2)

**Column C: Find IT Leaders**
- Enrichment: "Find people at company"
- Company domain: {{Company Domain}}
- Job titles: 
  - "IT Director"
  - "CTO"
  - "VP Technology"
  - "Director of Operations"
  - "Service Desk Manager"
  - "IT Manager"

**Column D: Find Contact Email**
- Enrichment: "Find email" (Hunter.io/Apollo)
- Person: {{Find IT Leaders.name}}
- Domain: {{Company Domain}}

**Column E: Verify Email**
- Enrichment: "Verify email"
- Email: {{Find Contact Email}}

**Column F: Find LinkedIn Profile**
- Enrichment: "Find person on LinkedIn"
- Name: {{Find IT Leaders.name}}
- Company: {{Company Name}}

**Column G: Enrich from LinkedIn**
- Get: current role, tenure, previous experience
- Look for PSA mentions in experience

**Column H: Calculate Lead Score (Formula)**
```javascript
let score = 0;

// Base score for PSA confirmation
if ({{PSA Confirmation}} === "Confirmed") score += 40;
else if ({{PSA Confirmation}} === "Review Mention Only") score += 20;

// Job posting mention
if ({{PSA in Job Postings}} === "Confirmed in Jobs") score += 20;

// Company size (MSPs typically 10-500 employees)
const empCount = parseInt({{Employee Count}});
if (empCount >= 10 && empCount <= 500) score += 15;

// Industry match
if ({{Industry}}?.toLowerCase().includes("it services") || 
    {{Industry}}?.toLowerCase().includes("managed service")) {
  score += 15;
}

// Email verified
if ({{Verify Email.valid}} === true) score += 10;

return score;
```

**Column I: Confidence Level (Formula)**
```javascript
const score = {{Calculate Lead Score}};
if (score >= 80) return "High";
else if (score >= 60) return "Medium";
else if (score >= 40) return "Low";
else return "Very Low";
```

---

## ENRICHMENT ALTERNATIVES (Free/Low Cost)

### If you don't have Firecrawl API:

**Option 1: Manual G2 Export**
1. Visit each G2 review page
2. Copy review data
3. Use Claude/ChatGPT to parse into CSV
4. Import to Clay

**Option 2: Use Web Scraper Chrome Extension**
1. Install Web Scraper extension
2. Create sitemap for G2 reviews
3. Export to CSV
4. Import to Clay

**Option 3: Use Apify**
- Cheaper than Firecrawl for one-time scrapes
- G2 scraper actor available
- Export directly to CSV

### Budget-Friendly Enrichment Stack:

| Step | Free Option | Paid Option |
|------|-------------|-------------|
| Company Domain | Hunter.io free tier | Clearbit |
| Email Finding | Hunter.io (100/mo free) | Apollo |
| Email Verification | NeverBounce free tier | ZeroBounce |
| LinkedIn Profiles | Manual search | LinkedIn Sales Nav |
| Tech Stack | Manual check | BuiltWith |

---

## EXPORT TO HUBSPOT

**Column J: Create HubSpot Contact**
- Integration: "Create/Update Contact in HubSpot"
- Email: {{Find Contact Email}}
- First Name: Parse from {{Find IT Leaders.name}}
- Last Name: Parse from {{Find IT Leaders.name}}
- Company: {{Company Name}}
- Job Title: {{Find IT Leaders.title}}

**Custom Properties to Set:**
- `psa_platform`: {{PSA Platform}}
- `psa_confidence`: {{Confidence Level}}
- `lead_score`: {{Calculate Lead Score}}
- `data_source`: "G2 Reviews"
- `discovered_date`: {{today}}

---

## FILTERING & SEGMENTATION

**High-Priority Leads (Create View):**
- Confidence Level = "High" OR "Medium"
- Employee Count between 20-500
- Email verified = true
- Industry contains "IT Services" OR "Managed Service"

**Export Segments:**
1. **Hot Leads**: Score 80+, email verified
2. **Warm Leads**: Score 60-79, company validated
3. **Research Needed**: Score 40-59, needs manual review

---

## AUTOMATION SCHEDULE

**Daily:**
- Check for new G2 reviews (use RSS or manual)
- Enrich new companies found

**Weekly:**
- Scrape all PSA platforms
- Update existing company data
- Find new decision makers

**Monthly:**
- Re-validate email addresses
- Update job posting checks
- Refresh tech stack data

---

## SUCCESS METRICS

Track in Clay or HubSpot:

- **Discovery Rate**: New PSA users found per week
- **Validation Rate**: % of companies confirmed using PSA
- **Contact Rate**: % with verified email found
- **Response Rate**: % of outreach responded to
- **Conversion Rate**: % becoming customers

---

## TROUBLESHOOTING

**Issue: G2 blocking scrapes**
- Solution: Use Firecrawl with stealth proxy
- Add `"proxy": "stealth"` to scrape request

**Issue: No emails found**
- Solution: Use waterfall enrichment
  1. Try Hunter.io
  2. If fails, try Apollo
  3. If fails, try RocketReach
  4. If fails, use LinkedIn InMail

**Issue: Too many false positives**
- Solution: Increase minimum lead score threshold
- Add manual review step for scores 50-70

**Issue: Duplicate companies**
- Solution: Use Clay's dedupe function on company domain
- Keep highest confidence record

---

## COST ESTIMATE (Monthly)

**Option A: Budget** (~$50/month)
- Firecrawl: Free tier (500 credits)
- Hunter.io: $49/mo (5,000 emails)
- Manual LinkedIn research
- **Expected output**: 100-200 qualified leads/month

**Option B: Standard** (~$200/month)
- Firecrawl: Starter ($16/mo)
- Apollo: $49/mo
- Hunter.io: $49/mo
- Clay: $149/mo
- **Expected output**: 500-1000 qualified leads/month

**Option C: Scale** (~$500/month)
- Firecrawl: Growth ($83/mo)
- BuiltWith: $295/mo
- Apollo: $79/mo
- Clay: $349/mo
- **Expected output**: 2000-5000 qualified leads/month

---

## NEXT STEPS

1. ✅ Set up Firecrawl account and get API key
2. ✅ Create Clay account and workspace
3. ⬜ Build Table 1 (Review Scraper)
4. ⬜ Test scrape on one PSA platform
5. ⬜ Build Table 2 (Company Enrichment)
6. ⬜ Add enrichment providers (Hunter, Apollo, etc.)
7. ⬜ Build Table 3 (Decision Maker Finding)
8. ⬜ Connect HubSpot integration
9. ⬜ Run first full discovery batch
10. ⬜ Analyze results and optimize

---

**Questions? Issues?**
- Firecrawl Docs: https://docs.firecrawl.dev
- Clay University: https://www.clay.com/university
- Support: Contact Joe Deville - Clay Works of Art
